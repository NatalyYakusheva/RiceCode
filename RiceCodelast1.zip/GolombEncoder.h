#pragma once

#include "BitStream.h"

class GolombEncoder
{
public:

	GolombEncoder(uint64_t m_);
	bool encode(uint64_t num);
	bool close();
	void resetBuffer();
	void setBuffer(uint8_t *buffer, uint64_t len);

	uint64_t getTotalCodeLength()
	{
		return bitStream.getTotalCodeLength();
	}

private:
	uint64_t rice_golombEncode(uint64_t num);
	BitOutputStream bitStream;
	uint64_t m;
	uint64_t k;
};