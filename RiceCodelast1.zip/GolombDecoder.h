#pragma once

#include "BitStream.h"
#include "GolombEncoder.h"

class GolombDecoder
{
public:

	GolombDecoder(uint64_t para);
	void setBuffer(uint8_t *buffer, int len);
	BufferState decode(uint64_t& num);
private:
	uint64_t rice_golombDecode();
	BitInputStream bitStream;
	uint64_t k;
	uint64_t m;
};