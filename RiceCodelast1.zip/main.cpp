#include "GolombEncoder.h"
#include "GolombDecoder.h"

#include <iostream>
#include <random>
#include <fstream>
#include <thread>
#include <string>
#include <mutex>
#include <chrono>
#include <utility>

using namespace std;

static const int length = 20;
static const int _max = 20;

static const unsigned int threadCount = 4;

mutex mtx;
static int counter = 0;
static const int MAX_COUNTER_VAL = 100;

void thread_proc(int tnum) {
	for (;;) {
		{
			lock_guard<mutex> lock(mtx);
			if (counter == MAX_COUNTER_VAL)
				break;
			int ctr_val = ++counter;
			cout << "Thread " << tnum << ": counter = " << ctr_val << endl;
		}
		this_thread::sleep_for(chrono::milliseconds(10));
	}
}

int main()
{
	
	vector<thread> threads;

	for (int i = 0; i < 10; i++) {
		thread thr(thread_proc, i);
		threads.emplace_back(move(thr));
	}

	// ����� ������ ������������ const auto &, ��� ��� .join () �� ������� ��� const
	for (auto& thr : threads) {
		thr.join();
	}




	
	ifstream binfile{ "example.bin", ios::binary };
	cout << binfile.rdbuf() << endl;
	filebuf* pbuf = binfile.rdbuf();
	size_t size = pbuf->pubseekoff(0, binfile.end, binfile.in);
	pbuf->pubseekpos(0, binfile.in);

	size_t tempSize = 1;
	while (tempSize <= size) tempSize <<= 1;
	size_t sizeBlock = (size_t)ceil(tempSize/threadCount);
	
	vector<vector<uint8_t>> all;
	char* buf = new char[sizeBlock];
	binfile.seekg(0, binfile.beg);
	for (int i = 0; i < threadCount; i++)
	{
		vector<uint8_t> v;


		memset(buf, 0, sizeBlock);

		binfile.read(buf, sizeBlock);
		v.assign(buf, buf + sizeBlock);
		all.push_back(v);
		cout.write(buf, sizeBlock);
		v.clear();
	}

	binfile.seekg(0, binfile.beg);
	cout << binfile.rdbuf() << endl;
	binfile.close();
	// ������ ������� � ����������� �����
	//cout.write(buf, size);
	for (int i = 0; i < all.size(); i++)
	{
		for (int j = 0; j < all[i].size(); j++)
		{
			cout << all[i][j] <<endl;
		}
	}
	cout << endl;
	

	uint8_t buffer[1024];
	memset(buffer, 0, 1024);

	GolombEncoder enc(5);
	enc.setBuffer(buffer, 1024);

	ofstream _ofs;
	_ofs.open("example2.bin", ios::binary);

	/*string su = to_string(sizeBlock) + '&' + to_string(threadCount) + '&';
	_ofs.write(su.c_str(), su.size());*/

	for (int i = 0; i < all.size(); i++)
	{
		for (int j = 0; j < all[i].size(); j++)
		{

			auto b = enc.encode(all[i][j]);
			if (!b)
			{
				cout << "Lack of buffer space,write the data to file" << endl;
				cout << "reset buffer" << buf;
				_ofs.write((const char*)buffer, enc.getTotalCodeLength());

				enc.resetBuffer();
				break;
			}
		}
		_ofs.write((const char*)buffer, enc.getTotalCodeLength());

	}

	enc.close();
	//_ofs.write((const char*)buffer, enc.getTotalCodeLength());
	_ofs.close();

	cout.write((const char*)buffer, enc.getTotalCodeLength());


	char* test = new char[all[1].size()]; //init this with the correct size

	std::copy(all[1].begin(), all[1].end(), test);
	cout << test[0] << test[1] << test[2] << test[3] << test[4] << test[5] << endl;
	//delete[] test;


	//delete[] buf;








	int k = 5;

	
	///////////////////////////////////////////////////////
	// Generate
	//////////////////////////////////////////////////////
	//ofstream codeofs;
	//codeofs.open("code.txt");

	//uint64_t *nums = new uint64_t[length];

	//random_device rd;
	//for (int n = 0; n < length; ++n)
	//{
	//	nums[n] = rd() % _max;
	//	codeofs << nums[n] << endl;
	//}
	//codeofs.close();
		
	////////////////////////////////////////////////////
	// Encode
	///////////////////////////////////////////////////

	//GolombEncoder encoder(5);
	//encoder.setBuffer(buffer, 1024);

	//ofstream ofs;
	//ofs.open("example.bin", ios::binary);

	//for (int i = 0; i < length; i++)
	//{
	//	auto b = encoder.encode(nums[i]);
	//	if (!b)
	//	{
	//		cout << "Lack of buffer space,write the data to file" << endl;
	//		cout << "reset buffer" << endl;
	//		ofs.write((const char*)buffer, encoder.getTotalCodeLength());

	//		encoder.resetBuffer();
	//		break;
	//	}
	//}
	//encoder.close();

	//ofs.write((const char*)buffer, encoder.getTotalCodeLength());
	//ofs.close();

	//cout << "Golomb finished coding" << endl;

	////////////////////////////////////////////////////////////////////
	// Decode
	////////////////////////////////////////////////////////////////////
	ifstream ifs;
	ifs.open("example2.bin", ios::binary);


	pbuf = ifs.rdbuf();
	// �������� ������ ����� � ������� ������ ������
	size = pbuf->pubseekoff(0, ifs.end, ifs.in);
	pbuf->pubseekpos(0, ifs.in);


	memset(buffer, 0, size);

	ifs.read((char*)buffer, size);
	cout << ifs.rdbuf() << endl;

	//int archiveSize, archiveCount;
	//string tempS = ""; int indexA = 0;
	//for (int j = 0; indexA < size && j <= 2; indexA++) {
	//	if (buffer[indexA] == '&')
	//	{
	//		if (j == 0)
	//		{
	//			archiveSize = atoi(tempS.c_str());
	//			tempS.clear();
	//			j++;
	//		}
	//		else if (j == 1)
	//		{
	//			archiveCount = atoi(tempS.c_str());
	//			tempS.clear();
	//			j++;
	//			break;
	//		}
	//		continue;
	//	}
	//	tempS += buffer[indexA];
	//}
	//cout << endl;






	ofstream encodeOfs;
	encodeOfs.open("encode.bin", ios::binary);

	GolombDecoder decoder(5);
	//decoder.setBuffer(&(buffer[indexA]), size-indexA);
	decoder.setBuffer(buffer, size);

	uint64_t num;
	auto state = decoder.decode(num);

	int index = 0;
	while (state != BufferState::BUFFER_END_SYMBOL)
	{
		encodeOfs << (const char) num;
		cout << num;
		state = decoder.decode(num);

		index++;
	}

	ifs.close();
	encodeOfs.close();

	cout << "decode finished" << endl;

	GolombEncoder expGolomb(k);
	expGolomb.setBuffer(buffer, 1024);

	expGolomb.encode(5);
	expGolomb.encode(9);
	expGolomb.encode(16);
	expGolomb.encode(27);
	
	expGolomb.close();

	GolombDecoder expDecoder(k);
	expDecoder.setBuffer(buffer, 1024);

	uint64_t a;
	expDecoder.decode(a);
	cout << a << endl;

	expDecoder.decode(a);
	cout << a << endl;

	expDecoder.decode(a);
	cout << a << endl;

	expDecoder.decode(a);
	cout << a << endl;

	getchar();
	return 0;
}