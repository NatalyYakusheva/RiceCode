#include "GolombEncoder.h"

GolombEncoder::GolombEncoder(uint64_t para)
{
	k = para;
	m = (int)pow(2, k);
}

void GolombEncoder::setBuffer(uint8_t* buffer, uint64_t len)
{
	bitStream.setBuffer(buffer, len);
}

void GolombEncoder::resetBuffer()
{
	bitStream.resetBuffer();
}

bool GolombEncoder::encode(uint64_t num)
{
	uint64_t len = 0;
	len = rice_golombEncode(num);
	return bitStream.freeLength() >= len;
}

bool GolombEncoder::close()
{
	return bitStream.flush();
}


uint64_t GolombEncoder::rice_golombEncode(uint64_t num)
{
	uint64_t q = num >> k;
	uint64_t r = num & (m - 1);

	auto len = q + 1 + k;

	bitStream.putBit(1, q);
	bitStream.putBit(0);

	for (int i = 0; i < k; i++)
	{
		bitStream.putBit(static_cast<bool>(r & 0x01));
		r >>= 1;
	}

	return len;
}
