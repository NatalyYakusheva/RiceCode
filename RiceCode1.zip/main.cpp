#include "GolombEncoder.h"
#include "GolombDecoder.h"

#include <iostream>
#include <random>
#include <fstream>
#include <thread>
#include <string>
#include <mutex>

using namespace std;

static const int length = 20;
static const int _max = 20;

int main()
{
	uint8_t buffer[1024];
	int k = 5;

	
	///////////////////////////////////////////////////////
	// Generate
	//////////////////////////////////////////////////////
	ofstream codeofs;
	codeofs.open("code.txt");

	uint64_t *nums = new uint64_t[length];

	std::random_device rd;
	for (int n = 0; n < length; ++n)
	{
		nums[n] = rd() % _max;
		codeofs << nums[n] << endl;
	}
	codeofs.close();
		
	////////////////////////////////////////////////////
	// Encode
	///////////////////////////////////////////////////
	GolombEncoder encoder(k);
	encoder.setBuffer(buffer, 1024);

	ofstream ofs;
	ofs.open("example.bin", ios::binary);

	for (int i = 0; i < length; i++)
	{
		auto b = encoder.encode(nums[i]);
		if (!b)
		{
			cout << "Lack of buffer space,write the data to file" << endl;
			cout << "reset buffer" << endl;
			ofs.write((const char*)buffer, encoder.getTotalCodeLength());

			encoder.resetBuffer();
			break;
		}
	}
	encoder.close();

	ofs.write((const char*)buffer, encoder.getTotalCodeLength());
	ofs.close();

	cout << "Golomb finished coding" << endl;

	////////////////////////////////////////////////////////////////////
	// Decode
	////////////////////////////////////////////////////////////////////
	ifstream ifs;
	ifs.open("example.txt", ios::binary);

	memset(buffer, 0, 1024);

	ifs.read((char*)buffer, 10);
	cout << ifs.rdbuf() << endl;
	ofstream encodeOfs;
	encodeOfs.open("encode.bin");

	GolombDecoder decoder(k);
	decoder.setBuffer(buffer, 1024);
	uint64_t num;
	auto state = decoder.decode(num);

	int index = 0;
	while (state != BufferState::BUFFER_END_SYMBOL)
	{
		encodeOfs << num << endl;
		state = decoder.decode(num);

		index++;
	}

	ifs.close();
	encodeOfs.close();

	cout << "decode finished" << endl;

	GolombEncoder expGolomb(k);
	expGolomb.setBuffer(buffer, 1024);

	expGolomb.encode(5);
	expGolomb.encode(9);
	expGolomb.encode(16);
	expGolomb.encode(27);
	
	expGolomb.close();

	GolombDecoder expDecoder(k);
	expDecoder.setBuffer(buffer, 1024);

	uint64_t a;
	expDecoder.decode(a);
	cout << a << endl;

	expDecoder.decode(a);
	cout << a << endl;

	expDecoder.decode(a);
	cout << a << endl;

	expDecoder.decode(a);
	cout << a << endl;

	getchar();
	return 0;
}