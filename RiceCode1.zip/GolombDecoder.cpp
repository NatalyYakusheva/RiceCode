#include "GolombDecoder.h"

GolombDecoder::GolombDecoder(uint64_t para)
{
	k = para;
	m = (int)pow(2, k);
}

void GolombDecoder::setBuffer(uint8_t* buffer, int len)
{
	bitStream.setBuffer(buffer, len);
}

BufferState GolombDecoder::decode(uint64_t& num)
{
	auto state = bitStream.check();
	if (state == BufferState::BUFFER_ENGOUGH)
	{
		num = rice_golombDecode();
	}
	return state;
}


// Rice Golomb
uint64_t GolombDecoder::rice_golombDecode()
{
	bool b;
	uint64_t unary = 0;
	b = bitStream.getBit();
	while (b)
	{
		unary++;
		b = bitStream.getBit();
	}

	std::bitset<64> bits;
	bits.reset();
	for (int i = 0; i < k; i++)
	{
		b = bitStream.getBit();
		bits.set(i, b);
	}

	uint64_t num = unary * m + bits.to_ulong();

	return num;
}
